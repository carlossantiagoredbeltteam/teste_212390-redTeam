This zip file contains the work in progress for Darwin (first release for the RepRap project).

Format is Solid Edge V19, Academic licence.

Main assembly file is Darwin3a.

This is pre-tidied, so beware of broken relationships and some redundant part files!

- Ed Sells (26/2/7)


Format is Solid Edge V19, Academic licence.

Main assembly file is Darwin 4.asm

Dummy extruder head.

- Ed Sells (24/9/07)

